import { useMemo, useState } from "react";
import ProductCard from "./ProductCard";
const PER_PAGE = 12;
export default function Shop({ products = [], categories = [], onAdd }) {
  const [cat, setCat] = useState("all");
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const list = useMemo(() => products.filter(p =>
    (cat === "all" || p.category === cat) && p.name.toLowerCase().includes(q.toLowerCase())), [products, cat, q]);
  const pages = Math.max(1, Math.ceil(list.length / PER_PAGE));
  const view = list.slice((page - 1) * PER_PAGE, page * PER_PAGE);
  const pick = c => { setCat(c); setPage(1); };
  return (
    <main className="shop">
      <div className="shop-h">
        <div className="eyebrow">The collection</div>
        <h1>all fragrances</h1><hr />
      </div>
      <label className="search">
        <svg width="16" height="16" fill="none" stroke="#9ca3af" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4-4"/></svg>
        <input placeholder="Search fragrances..." value={q} onChange={e => { setQ(e.target.value); setPage(1); }} />
      </label>
      <div className="tabs">
        {["all", ...categories].map(c => <button key={c} className={cat === c ? "on" : ""} onClick={() => pick(c)}>{c}</button>)}
      </div>
      <div className="grid">{view.map(p => <ProductCard key={p._id} p={p} onAdd={onAdd} />)}</div>
      <div className="pager">
        <button disabled={page === 1} onClick={() => setPage(page - 1)}>‹ Previous</button>
        <em>{page} of {pages}</em>
        <button disabled={page === pages} onClick={() => setPage(page + 1)}>Next ›</button>
      </div>
    </main>
  );
}
