import { Link } from "react-router-dom";
import ProductCard from "./ProductCard";
// Pass your own copy/images via props. rows: [{title, sub, to, products, align:"left"|"right"}]
export default function Home({ hero, philosophy, categories = [], rows = [], founder, cta, onAdd }) {
  return (
    <>
      <section className="hero" style={{ backgroundImage: `url(${hero.image})` }}>
        <div>
          <div className="eyebrow">{hero.eyebrow}</div>
          <h1>{hero.title}<i>{hero.subtitle}</i></h1>
          <p>{hero.text}</p>
          <div className="btns">
            <Link className="btn solid" to="/shop">Explore collection</Link>
            <Link className="btn ghost" to="/about">Our story</Link>
          </div>
        </div>
      </section>
      <section className="philo"><div className="eyebrow">{philosophy.label}</div><q>{philosophy.quote}</q></section>
      <section className="cats">
        {categories.map(c => (
          <Link key={c.name} to={c.to}>
            <img src={c.image} alt={c.name} loading="lazy" />
            <h3>{c.name}</h3><span className="eyebrow">{c.tagline}</span><hr />
          </Link>
        ))}
      </section>
      {rows.map(r => (
        <section key={r.title} className={`row ${r.align === "right" ? "right" : ""}`}>
          <div className="row-h">
            <div><h2>{r.title}</h2><div className="eyebrow">{r.sub}</div></div>
            <Link className="link-u" to={r.to}>View all</Link>
          </div>
          <div className="row-g">{r.products.slice(0, 4).map(p => <ProductCard key={p._id} p={p} onAdd={onAdd} />)}</div>
        </section>
      ))}
      <section className="founder">
        <div className="pic"><img src={founder.image} alt="" /><span className="est">{founder.est}</span></div>
        <div><h2>{founder.title}<i>{founder.italic}</i></h2><p>{founder.quote}</p><div className="sign">{founder.name}</div></div>
      </section>
      <section className="cta">
        <div className="eyebrow">{cta.label}</div>
        <h2>{cta.title}<i>{cta.italic}</i></h2><p>{cta.text}</p>
        <a className="link-u" href={cta.href} target="_blank" rel="noreferrer">{cta.button}</a>
      </section>
    </>
  );
}
