import { Link } from "react-router-dom";
export default function Footer({ logo, tagline, collections = [], whatsapp, instagram, brand = "Scent Design" }) {
  return (
    <footer className="ftr">
      <div className="ftr-g">
        <div><img src={logo} alt={brand} /><p>{tagline}</p></div>
        <div><h4>Collections</h4>{collections.map(c => <Link key={c.to} to={c.to}>{c.label}</Link>)}</div>
        <div><h4>Support</h4><Link to="/contact">Contact Us</Link></div>
        <div><h4>Join us</h4>
          {instagram && <a href={instagram} target="_blank" rel="noreferrer">Instagram</a>}
          {whatsapp && <a href={whatsapp} target="_blank" rel="noreferrer">WhatsApp</a>}
        </div>
      </div>
      <div className="ftr-b"><span>© {new Date().getFullYear()} {brand}</span><span>Made in Nigeria</span></div>
    </footer>
  );
}
