import { useState } from "react";
import { Link } from "react-router-dom";
const naira = n => "₦" + Number(n).toLocaleString("en-NG");
// Map your DB fields here: name, category, price, oldPrice, size, description, image, stock, bestSeller, variants[], rating, reviewCount
export default function ProductCard({ p, onAdd }) {
  const [variant, setVariant] = useState("");
  const [more, setMore] = useState(false);
  const out = p.stock === 0;
  return (
    <article className="card">
      <Link to={`/product/${p._id}`} className="img">
        <img src={p.image} alt={p.name} loading="lazy" />
        {p.stock > 0 && p.stock < 5 && <span className="badge">&lt;5 units left</span>}
        {p.limited && <span className="badge dark">Limited</span>}
        {p.bestSeller && <span className="badge dark" style={{ top: p.stock < 5 ? 34 : 0 }}>Best seller</span>}
        {p.oldPrice > p.price && <span className="badge sale">Sale</span>}
      </Link>
      <h3>{p.name}</h3>
      <div className="cat">{p.category}</div>
      <div className="price">{naira(p.price)}{p.oldPrice > p.price && <s>{naira(p.oldPrice)}</s>}</div>
      {p.description && (
        <div className={`desc ${more ? "" : "clamp"}`}>{p.description}
          {p.description.length > 90 && <button className="more" onClick={() => setMore(!more)}>{more ? "Show less" : "...Show more"}</button>}
        </div>)}
      {p.size && <div className="size">{p.size}</div>}
      {p.variants?.length > 0 && (
        <select value={variant} onChange={e => setVariant(e.target.value)}>
          <option value="">-- Choose fragrance --</option>
          {p.variants.map(v => <option key={v}>{v}</option>)}
        </select>
      )}
      <div className="stars"><span>{"★".repeat(Math.round(p.rating || 4))}</span>({p.reviewCount || 0}) reviews</div>
      <button className="add" onClick={() => onAdd(p, variant)} disabled={out || (p.variants?.length > 0 && !variant)}>{out ? "Out of stock" : "Add to cart"}</button>
    </article>
  );
}
