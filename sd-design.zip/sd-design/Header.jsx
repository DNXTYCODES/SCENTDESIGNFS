import { Link } from "react-router-dom";
// variant: "light" (transparent over hero) | "solid" (white)
export default function Header({ variant = "solid", cartCount = 0, onCart, logo }) {
  return (
    <header className={`hdr ${variant} ${variant === "light" ? "light" : ""}`}>
      <Link to="/"><img src={logo} alt="Scent Design" /></Link>
      <nav>
        <Link to="/shop">Shop</Link>
        <button className="bag" onClick={onCart} aria-label="Cart">
          <svg width="24" height="24" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><path d="M6 8h12l1 12H5L6 8zM9 8a3 3 0 016 0"/></svg>
          {cartCount > 0 && <b>{cartCount}</b>}
        </button>
      </nav>
    </header>
  );
}
